git clone https://github.com/SerenityOS/serenity.git
git checkout 7537a045e5f127804040e44b13dcca3c7a5de3c6
git apply serenity.patch
Meta/serenity.sh run lagom js
