#! /usr/bin/python3
import os
import subprocess
import sys
import uuid
import encodings.idna

def socket_print(string):
    print("=====", string, flush=True)


def get_user_input(filename):
    socket_print("Input your register script:")
    
    with open(filename,"w") as f:
        while True:
            code = input()
            if "END" in code:
                f.write(code.replace("END", "")+'\n')
                break
            f.write(code+'\n')
    socket_print("Got the file.")


def run_challenge(filename):
    try:
        result = subprocess.check_output("/home/ctf/pwn {}".format(filename), shell=True)
        socket_print(result.decode())
    except:
        socket_print("ERROR DETECTED.")
        clean(filename)
        exit(0)
    socket_print("DONE.")
    clean(filename)

def get_filename():
    return "/tmp/{}".format(uuid.uuid4().hex[:4])

def clean(filename):
    os.remove(filename)

def main():
    filename = get_filename()
    get_user_input(filename)
    run_challenge(filename)


if __name__ == "__main__":
    main()