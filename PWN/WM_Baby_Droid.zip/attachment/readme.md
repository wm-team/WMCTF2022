# Task description
Here is a vulnerable Android client application running in an AVD simulated environment. I placed the flag file in the app's internal storage(/data/data/{pkg}/files/flag) or Cookies file(/data/data/{pkg}/app_webview/Cookies). Now you have a chance to install malicious app into the system. Can you exploit and steal the contents of the flag file through these vulnerabilities?

The vulnerable Android client application is named app-debug.apk, you can use jadx (https://github.com/skylot/jadx/releases) to perform a reverse analysis.

In addition, the real flag is stored in the remote server, you need access server by `nc ip port` or socket. In order to prevent DOS, I set up a proof-of-work. If you feel troublesome, you can use `launch.py` to send your apk link automatically.

Once you capture the flag, you can send it back by performing a network request. So you may need to set these in AndroidManifest.xml:
```xml
<uses-permission android:name="android.permission.INTERNET"/>
......
<application
    android:usesCleartextTraffic="true"
    ......
```

You can set up a temporary http service, to provide apk_download_url, and record flag. Example:

- using node: `anywhere -l 80 -s`
- using python3: `python3 -m http.server 80`

```bash
mkdir temp;cd temp; anywhere -l 80 -s
# mv ./app-debug.apk ./temp/app-debug.apk
```

You can also use `nc -l 233` to listen a port and record flag. Try this

```bash
nc -l 233

curl 127.0.0.1:233
echo flag{test} | nc 127.0.0.1 233
```



# Run your own independent environment
In most cases, you can create your own AVD image consistent with the Dockerfile to complete the writing and debugging of EXP script. If you want to be consistent with the process of the task, you can deploy a separate environment yourself.

## Run in Linux
First, check if your linux machine meets kvm
```bash
egrep -c '(vmx|svm)' /proc/cpuinfo # Should be greater than 0
```

Then install and set up docker
```bash
sudo apt install docker-ce
./run.sh
```

Finally, you can access task by
```
nc {ip} {port in ./run.sh}
```

## Run in macos

Please refer to the Dockerfile to install the corresponding tools and images first.
(Most of them can be installed through Android Studio, and please ensure the relevant command-line-tools are involved in your $PATH)

Then
```bash
./server.py 1
```
