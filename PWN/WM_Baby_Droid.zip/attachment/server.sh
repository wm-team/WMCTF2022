#!/bin/bash
while true; do ps -efl | grep emulator | awk '{if ($5 == 1){print $4}}' | xargs kill -9 2&>/dev/null; sleep 10; done &
chmod 0777 /dev/kvm
socat TCP-LISTEN:1337,reuseaddr,fork EXEC:"/bin/timeout 300 /challenge/server.py"